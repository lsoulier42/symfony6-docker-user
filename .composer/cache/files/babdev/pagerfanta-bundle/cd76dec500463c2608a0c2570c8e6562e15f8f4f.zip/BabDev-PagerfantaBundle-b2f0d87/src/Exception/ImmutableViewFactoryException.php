<?php declare(strict_types=1);

namespace BabDev\PagerfantaBundle\Exception;

use Pagerfanta\Exception\RuntimeException;

final class ImmutableViewFactoryException extends RuntimeException {}
