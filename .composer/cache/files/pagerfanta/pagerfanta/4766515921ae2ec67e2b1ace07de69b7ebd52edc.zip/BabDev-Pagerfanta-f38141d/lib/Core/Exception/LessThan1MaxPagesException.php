<?php declare(strict_types=1);

namespace Pagerfanta\Exception;

class LessThan1MaxPagesException extends NotValidMaxPerPageException
{
}
