<?php declare(strict_types=1);

namespace Pagerfanta\Exception;

class InvalidArgumentException extends \InvalidArgumentException implements PagerfantaException
{
}
