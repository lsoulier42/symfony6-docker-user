<?php declare(strict_types=1);

namespace Pagerfanta\Exception;

class NotValidMaxPerPageException extends InvalidArgumentException
{
}
