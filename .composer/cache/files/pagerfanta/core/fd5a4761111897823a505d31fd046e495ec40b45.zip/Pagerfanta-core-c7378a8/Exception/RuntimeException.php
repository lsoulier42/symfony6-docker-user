<?php declare(strict_types=1);

namespace Pagerfanta\Exception;

class RuntimeException extends \RuntimeException implements PagerfantaException
{
}
