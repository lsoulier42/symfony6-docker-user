<?php declare(strict_types=1);

namespace Pagerfanta\Exception;

class LogicException extends \LogicException implements PagerfantaException
{
}
